<?php require('header.php'); ?>
<!--<section class="mbr-box mbr-section mbr-section--relative mbr-section--fixed-size  mbr-section--bg-adapted mbr-parallax-background mbr-after-navbar" id="header1-73" >
    <div class="mbr-box__magnet mbr-box__magnet--sm-padding mbr-box__magnet--center-left">
        <div class="mbr-overlay" style="opacity: 0.6; background-color: #80bfff;"></div>
        <div class="mbr-box__container mbr-section__container container">
            <div class="mbr-box mbr-box--stretched"><div class="mbr-box__magnet mbr-box__magnet--center-left">
                 <div class="col-xs-18 col-sm-12 col-md-12">

            <center><h1>Invest in businesses you truly believe in!</h1></center>
              <br>
                <h4><center>Discover a world of great investment opportunities, buy into businesses you believe in and share in their success through a simple online process.</center></h4>
                
           <br>
          <div class="mbr-buttons  mbr-buttons--left"><center><a class="mbr-buttons__btn btn btn-lg animated fadeInUp delay btn-warning" data-toggle="modal" href="#knowmore">Know more!</a></center>
        </div>
            </div></div>
        </div>
      
    </div>
</section>
-->


<section class="content-2 col-4" style="background-color: rgb(255, 255, 255);">
    
    <div class="container">
        <h1 style="color:rgb(0,177,240);"><center>You are a</center></h1>
        <a href="investor_signup.php"><div class="col-lg-6"><center><img width="50%"src="http://www.investormarketinglists.com/wp-content/uploads/2011/05/62000.gif"/><br></center></div></a>
    
        <a href="venture_signup.php"><div class="col-lg-6"><center><img src="http://cdn.skateboarding.transworld.net/wp-content/blogs.dir/440/files/2012/12/venture-logo.jpg"/></center></div></a>
    </div>
</section>
<?php require('footer.php'); ?>