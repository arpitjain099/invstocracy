<?php 
header('Access-Control-Allow-Origin: *');

$con=mysqli_connect("localhost","rbansal","rbansal","rashmibansal");
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
    echo "<br />";
  }

  $name=$_POST["name"];
  $entity=$_POST['entity'];
  $email=$_POST['email'];
  $phone=$_POST['phone'];
  $headline=$_POST['headline'];
  $location=$_POST['location'];
  $preferences=$_POST['preferences'];
  $pastinvestments=$_POST['pastinvestments'];


$result = mysqli_query($con,"SELECT * FROM `users_fmv` WHERE email = '$email'");
//var_dump($result);
   if($result->num_rows > 0){
      echo "user already exists";return;
   }

else{
$strs=md5($email+$name);
  $sql1="INSERT INTO users_fmv VALUES('$name','$strs','$entity','$email','$phone','$headline','$location','$preferences','$pastinvestments','pending');";
$result2 = mysqli_query($con,$sql1);
echo "ok";return;
}

?>