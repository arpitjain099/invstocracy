<?php 
header('Access-Control-Allow-Origin: *');
$con=mysqli_connect("localhost","rbansal","rbansal","rashmibansal");
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
    echo "<br />";
  }
  $email=$_POST['emailid'];
$name=$_POST['name'];
$gender=$_POST['gender'];
$google_id=$_POST['google_id'];
$picture=$_POST['picture'];
$profile=$_POST['profile'];
//echo $email;echo $profile;echo $picture;echo $name;echo $gender;echo $google_id;
  //echo $a1;
$result = mysqli_query($con,"SELECT * FROM `users` WHERE email = '$email'");

   if($result->num_rows > 0){
      echo "ok";return;
   }
else{
  $sql1="INSERT INTO users VALUES('$email','$name','$gender','$google_id','$picture','$profile','[]');";
$result = mysqli_query($con,$sql1);
echo "ok1";return;
}
 //$sql="SELECT * FROM login WHERE login.username='$a' AND login.password='$b';";
  $res1=mysqli_query($con,$sql1);
  if (!$res1) {
    die('Error:Please make the entry again,either the person does not exist or you have made some mistake !' . mysql_error());
}
?>