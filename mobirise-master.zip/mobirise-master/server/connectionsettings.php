<?php
$servername = "localhost:8080";
$username = "root";
$password = "";
$dbname = "fundmyventure";
?>