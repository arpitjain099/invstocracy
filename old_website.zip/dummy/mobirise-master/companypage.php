<?php require('header.php');?>


<section class="mbr-slider mbr-section mbr-section--no-padding carousel slide" data-ride="carousel" data-wrap="true" data-interval="5000" id="slider-38" style="background-color: rgb(255, 255, 255);">
    <div class="mbr-section__container">
        <div>
            <!--<ol class="carousel-indicators">
                <li data-app-prevent-settings="" data-target="#slider-38" class="active" data-slide-to="0"></li>
                <li data-app-prevent-settings="" data-target="#slider-38" data-slide-to="1"></li>
                <li data-app-prevent-settings="" data-target="#slider-38" data-slide-to="2"></li>
            </ol>-->
            <img src="16859704251_60658b717e_o__1454180652_106.51.243.101.jpg"/>
        </div>
    </div>
</section>