
<section class="mbr-section mbr-section--relative mbr-section--fixed-size" id="contact" style="background-color: rgb(60, 60, 60);">
    
    <div class="mbr-section__container container" >
        <div class="mbr-contacts mbr-contacts--wysiwyg row">
            <div class="col-sm-6">
                 <p class="mbr-contacts__text"><strong>Reach out</strong><br>
E-mail - <a href="mailto:reachout@fundmyventure.co">reachout@fundmyventure.co</a><br>
Phone - 080-95994233<br><br>

            </div>
            <div class="col-sm-6">
                <div class="row">
                    <div class="col-sm-5 col-sm-offset-1">
                       
                    </div>
                    <div class="col-sm-6"><p class="mbr-contacts__text"><strong>Join us</strong></p><ul class="mbr-contacts__list">
                        <a href="https://medium.com/fund-my-venture" target="_blank"><li>Learn</li></a>
                        <a href="glossary.php"><li>Glossary</li></a>
                        <a data-toggle="modal" data-target="#joinus"><li>Join us</li></a>
                        <a href="https://medium.com/fund-my-venture" target="_blank"><li>Blog</li></a>
                    </ul></div>
                   

                </div>
            </div>

        </div>
 <center><p style="color:white;">Made with <span class="glyphicon glyphicon-heart-empty"></span> in Bangalore!</p>
</center>

    </div>
</section>



  <script src="assets/jquery/jquery.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js"></script>
  <script src="assets/smooth-scroll/SmoothScroll.js"></script>
  <script src="assets/bootstrap-carousel-swipe/bootstrap-carousel-swipe.js"></script>
  <script src="assets/jarallax/jarallax.js"></script>
  <script src="assets/masonry/masonry.pkgd.min.js"></script>
  <script src="assets/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/social-likes/social-likes.js"></script>
  <script src="assets/fundmyventure/js/script.js"></script>
  <script src="assets/fundmyventure-gallery/script.js"></script>
  
  <script type="text/javascript">
$( window ).load(function() {
  
 // Code commented for now
 //$('#windowloadmodal').modal('show');
});
    </script>
</body>
</html>