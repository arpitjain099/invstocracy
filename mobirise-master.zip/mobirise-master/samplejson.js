var data={
  "name": "Arpit Jain",
  "entity": "FundMyVenture",
  "headline": "Growth Hacker, Computer Scientist",
  "location": "Bangalore",
  "location_short": "Bangalore, IN",
  "investor_type": "Angel",
  "linkedin": "http:\/\/in.linkedin.com\/arpitjain099",
  "twitter": "http:\/\/twitter.com\/arpitjay",
  "currentorg": "Xerox",
  "designation": "Research Engineer",
  "city": "Bangalore",
  "country": "India",
  "interests": [
    {
      "area": "Cleantech"
    },
    {
      "area": "Biofuels"
    },
    {
      "area": "Virtual Reality"
    },
    {
      "area": "Artifical Intelligence"
    }
  ],
  "noofinvestments": "3",
  "typcalinvestmentamount": "1-2 lacs",
  "portfolio": [
    {
      "name": "ABC Private Limited"
    },
    {
      "name": "XYZ LLC"
    },
    {
      "name": "PQR Private Limited"
    }
  ],
  "image_url": "https:\/\/qph.is.quoracdn.net\/main-thumb-5744486-200-krg8c8s6D8kjcE2T9u3UoknYAssetQVA.jpeg",
  "following": [
    {
      "name": "JKL Private Limited",
      "url": "companypage.php",
      "tagline": "Some text goes here. Some text goes here. Some text goes here. Some text goes here. Some text goes here. ",
      "photo": "http:\/\/placehold.it\/500x250\/EEE"
    },
    {
      "name": "QWR Private Limited",
      "url": "companypage.php",
      "tagline": "Some text goes here. Some text goes here. Some text goes here. Some text goes here. Some text goes here. ",
      "photo": "http:\/\/placehold.it\/500x250\/EEE"
    },
    {
      "name": "ABC Private Limited",
      "url": "companypage.php",
      "tagline": "Some text goes here. Some text goes here. Some text goes here. Some text goes here. Some text goes here. ",
      "photo": "http:\/\/placehold.it\/500x250\/EEE"
    },
    {
      "name": "XYZ Private Limited",
      "url": "companypage.php",
      "tagline": "Some text goes here. Some text goes here. Some text goes here. Some text goes here. Some text goes here. ",
      "photo": "http:\/\/placehold.it\/500x250\/EEE"
    }
  ]
}