
<?php require('header.php'); ?>
<style type="text/css">
.panel-title:hover {
     cursor: pointer;
}
</style>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  
<section class="mbr-box mbr-section mbr-section--relative mbr-section--fixed-size mbr-section--full-height mbr-section--bg-adapted mbr-parallax-background mbr-after-navbar" id="header1-73" >
    <div class=" mbr-box__magnet--sm-padding mbr-box__magnet--center-left">

<div class="container">
<h1>Frequently Asked Questions</h1>
<a href="#general"><h4>General Questions about FundMyVenture</h4></a>
<a href="#generalinvestor"><h4>General Investor Questions</h4></a>
<a href="#investinequity"><h4>Invest in Equity</h4></a>
<a href="#investindebt"><h4>Invest in Debt</h4></a>
<a href="#raisecapitalequity"><h4>Companies - Raise capital in return of equity</h4></a>
<a href="#raisecapitaldebt"><h4>Companies - Raise capital as debt</h4></a>
<br>
<div id="general">
   <h4>General Questions about FundMyVenture</h4>
<div class="panel-group" id="accordion1">
    <!-- First Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse" 
                 data-target="#collapseOne">
                 What is FundMyVenture?
             </h4>
        </div>
        <div id="collapseOne" class="panel-collapse collapse">
            <div class="panel-body">
               FundMyVenture is one of its discovery and deal making platform to help startups raise funds easily and efficiently. We believe that great ideas are brimming in India, but they die an early death due to lack of funds and social validation. We are often referred to as a crowdfunding platform, marketplace lender, or peer-to-peer lender. Whatever term you choose to use, we are here to connect investors who want to invest in innovative businesses that need real capital – either through debt or equity - it’s that simple. Our aim is to democratize the way Indian startups raise funds by going directly to the people (thanks to favorable proposals from the #StartupIndia initiative by the Government of India). People support these business proposals not for charity, but in return for equity. If the company you invest in makes it big, you also get a share in their growth story. Music to the ears, isn't it? :)
               
               <br><br>Through FundMyVenture platform, accredited and institutional investors have the opportunity to invest in real estate opportunities online through a private, secure website. Investors can browse investments, review due diligence materials and sign legal documents securely online. Once invested, investors have access to an investor dashboard, giving them 24/7 access to watch how their money is working for them.
<br><br>
Businesses looking for debt or equity capital can do so by filling out an online application, creating an account and going through our due diligence process.
<br><br>
We are here to bring easy investment opportunities to everyone through the use of technology.
            </div>
        </div>
    </div>
    
    <!-- Second Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title" 
                 data-toggle="collapse" 
                 data-target="#1_2">
                 How do I get started on FundMyVenture.co?
             </h4>
        </div>
        <div id="1_2" class="panel-collapse collapse">
            <div class="panel-body">
                If you want to invest money, you can start <a href="investors.php">here</a>.

If you are looking for debt or equity for your business, you can start by completing an application <a href="businesses.php">here</a>. </div>
        </div>
    </div>
    
    <!-- Third Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse"
                 data-target="#1_3">
                 Who is FundMyVenture?
             </h4>
        </div>
        <div id="1_3" class="panel-collapse collapse">
            <div class="panel-body">
                FundMyVenture.co is a team of professionals, with experience in private equity, technology and finance. You can learn more about us <a href="about.php">here</a>.
            </div>
        </div>
    </div>
 <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse"
                 data-target="#1_4">
                 How is this different than a traditional Angel Groups/Seed Funds/Venture Capital Firms?
             </h4>
        </div>
        <div id="1_4" class="panel-collapse collapse">
            <div class="panel-body">
                We are very different from traditional Angel Groups/Seed Funds/Venture Capital Firms in the following aspects.<br><br>
                <b>Angel Groups</b>: Instead of the letting the general partner or the managing team decide which companies to pitch, FundMyVenture allows investors to pick businesses and teams as per their liking. We strongly believe that every investor should have to freedom to vet businesses to which he/she can provide the maximum inputs apart from financial help. This, however, does not mean that you are alone in your investment, we also connect you with other investors interested in the deal so that you can collectively work on opportunities around the business.<br><br>
                <b>Seed funds</b>: We don't use institutional funds to support businesses. We, in a way, crowdsource investment opportunities to individuals/organizations to help them invest as per their tastes and interests.<br><br>
                <b>Venture Capital Firms</b>: Like seed funds, we don't rely on institutional funds. Besides that, we currently operate in a much limited capacity compared to venture capital firms. In fact, for most of our investments, we try to push the startups that come to our platform for venture capital funding in later stage of their businesses, which also acts in interest for investors on FundMyVenture platform.

            </div>
        </div>
    </div>
     <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse"
                 data-target="#1_5">
                 How is FundMyVenture different from Mutual Funds?
             </h4>
        </div>
        <div id="1_5" class="panel-collapse collapse">
            <div class="panel-body">
                We are not a mutual fund. SEBI (Securities and Exchange Board of India) actually does a very good job in their process while assigning Mutual Fund status to a company. Unlike mutual funds which invest in publicly traded stocks, we provide our investors with investment opportunities in unlisted companies.<br><br>
                When investing in a mutual, most investors have little to no information regarding actual stocks the fund invests in and cannot invest based on their specific preferences. With FundMyVenture, investors can invest in individual private equity deals giving added transparency and control over investment selection (for example, deal type – you may believe in retail, but not so much in technology or the other way around), location, return profile, and hold period(if applicable).<br><br>
                In addition, Mutual Funds are such large entities that they can rarely participate in many of the smaller investments FundMyVenture has access to, such as startups and even family businesses.<b>
                We give investors access to deals they have never had access to before.</b>
            </div>
        </div>
    </div>
     <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse"
                 data-target="#1_6">
                 Is FundMyVenture secure?
             </h4>
        </div>
        <div id="1_6" class="panel-collapse collapse">
            <div class="panel-body">
               FundMyVenture is committed to protecting the privacy and confidentiality of information. This includes but is not limited to physical and electronic procedures to protect information from loss, misuse, damage or modification by unauthorized access. Some of the central features of our security program are:

1. Internal and external review of our public and non-public Internet sites and services;
2. Rigorous multi-stage testing of the operability of products and features before they are exposed to the Internet as well as updates for known vulnerabilities;
3. Monitoring of our systems infrastructure to detect weaknesses and potential intrusions.
4. We <b>never</b> share any of the information on our platform with third party vendors without taking due consent from the parties involved. Startups, believe us, your idea and details are safe with us. The same thing applies to investors as well.

<br><br>Things to expect in future:<br>
We are still an early stage company, and will incorporate features like firewalls and encryption very soon. Startups and investors should not still worry, as until we have the systems in place, we have your data safe with us in physical form away from our servers/database to prevent any untoward attack on our systems.
            </div>
        </div>
    </div>
     <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse"
                 data-target="#1_7">
                 Who are the people behind FundMyVenture?
             </h4>
        </div>
        <div id="1_7" class="panel-collapse collapse">
            <div class="panel-body">
                The company was founded by Arpit Jain and the platform was formally launched in January 2016. Later Ruchi Dana and Rajeev Ramanath joined the company.<br><br>

Arpit Jain is currently the CEO of the company, responsible for the company’s strategic direction and operations. Arpit has previously worked on Computer Science research with Xerox Research Labs, India and has internship experience with Yahoo, and Zomato. He also has been on internships to IRIT (France), Indian Institute of Management Bangalore (IIMB) and Indian Institute of Management Calcutta (IIMC). Arpit possesses a bachelors and masters degree in Computer Science & Engineering from IIT Kanpur, India. Arpit holds 2 patent applications and 2 publications so far and was among the founding team of Entrepreneurship Cell at IIT Kanpur.<br><br>

Ruchi is currently the CFO of the company, responsible for the financial analysis and due diligence wing at FundMyVenture. Ruchi, who sits on FundMyVenture.co’s board, is also a board member with DANA Group, which is one of biggest steel conglomerates based out of Dubai. She also has experience working with New Silk Route and Golden Seeds, both of which are venture Capital & private Equity firms based out of NY. Ruchi has been very close to startups and launched PikAVenture in 2013 to help startups raise money from angel investors. She has a MBA from Stanford Graduate School of Business and MBBS degree from Aligarh Muslim University.
<br><br>

Rajeev is currently a partner who handles the legal aspects of a deal starting from formulating termsheets, and other documentation keeping the interest and safety of the investor as the first priority. Rajeev is a certified chartered accountatn holds CA charter from ICAI. He also has experience teaching students for CA/CS exams in Palakkad.


            </div>
        </div>
    </div>
     <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse"
                 data-target="#1_3">
                 Who is FundMyVenture?
             </h4>
        </div>
        <div id="1_3" class="panel-collapse collapse">
            <div class="panel-body">
                FundMyVenture.co is a team of professionals, with experience in private equity, technology and finance. You can learn more about us <a href="about.php">here</a>.
            </div>
        </div>
    </div>
     <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse"
                 data-target="#1_3">
                 Who is FundMyVenture?
             </h4>
        </div>
        <div id="1_3" class="panel-collapse collapse">
            <div class="panel-body">
                FundMyVenture.co is a team of professionals, with experience in private equity, technology and finance. You can learn more about us <a href="about.php">here</a>.
            </div>
        </div>
    </div>












</div>
    
    </div>
    
<div id="investinequity">
    <h4>General Investor Questions</h4>
<div class="panel-group" id="accordion2">
    <!-- First Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse" 
                 data-target="#collapseOne">
                 Collapsible Group Item #1
             </h4>
        </div>
        <div id="collapseOne" class="panel-collapse collapse">
            <div class="panel-body">
                Anim pariatur cliche reprehenderit, 
                enim eiusmod high life accusamus terry richardson ad squid.
            </div>
        </div>
    </div>
    
    <!-- Second Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title" 
                 data-toggle="collapse" 
                 data-target="#collapseTwo">
                 Collapsible Group Item #2
             </h4>
        </div>
        <div id="collapseTwo" class="panel-collapse collapse">
            <div class="panel-body">
                Anim pariatur cliche reprehenderit, 
                enim eiusmod high life accusamus terry richardson ad squid.
            </div>
        </div>
    </div>
    
    <!-- Third Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse"
                 data-target="#collapseThree">
                 Collapsible Group Item #3
             </h4>
        </div>
        <div id="collapseThree" class="panel-collapse collapse">
            <div class="panel-body">
                Anim pariatur cliche reprehenderit, 
                enim eiusmod high life accusamus terry richardson ad squid.
            </div>
        </div>
    </div>
</div>
    
    </div>


<div id="investindebt">
    <h4>Invest in Equity</h4>
<div class="panel-group" id="accordion3">
    <!-- First Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse" 
                 data-target="#collapseOne">
                 Collapsible Group Item #1
             </h4>
        </div>
        <div id="collapseOne" class="panel-collapse collapse">
            <div class="panel-body">
                Anim pariatur cliche reprehenderit, 
                enim eiusmod high life accusamus terry richardson ad squid.
            </div>
        </div>
    </div>
    
    <!-- Second Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title" 
                 data-toggle="collapse" 
                 data-target="#collapseTwo">
                 Collapsible Group Item #2
             </h4>
        </div>
        <div id="collapseTwo" class="panel-collapse collapse">
            <div class="panel-body">
                Anim pariatur cliche reprehenderit, 
                enim eiusmod high life accusamus terry richardson ad squid.
            </div>
        </div>
    </div>
    
    <!-- Third Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse"
                 data-target="#collapseThree">
                 Collapsible Group Item #3
             </h4>
        </div>
        <div id="collapseThree" class="panel-collapse collapse">
            <div class="panel-body">
                Anim pariatur cliche reprehenderit, 
                enim eiusmod high life accusamus terry richardson ad squid.
            </div>
        </div>
    </div>
</div>
    
    </div>


<div id="investinequity">
    <h4>Invest in Debt</h4>
<div class="panel-group" id="accordion4">
    <!-- First Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse" 
                 data-target="#collapseOne">
                 Collapsible Group Item #1
             </h4>
        </div>
        <div id="collapseOne" class="panel-collapse collapse">
            <div class="panel-body">
                Anim pariatur cliche reprehenderit, 
                enim eiusmod high life accusamus terry richardson ad squid.
            </div>
        </div>
    </div>
    
    <!-- Second Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title" 
                 data-toggle="collapse" 
                 data-target="#collapseTwo">
                 Collapsible Group Item #2
             </h4>
        </div>
        <div id="collapseTwo" class="panel-collapse collapse">
            <div class="panel-body">
                Anim pariatur cliche reprehenderit, 
                enim eiusmod high life accusamus terry richardson ad squid.
            </div>
        </div>
    </div>
    
    <!-- Third Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse"
                 data-target="#collapseThree">
                 Collapsible Group Item #3
             </h4>
        </div>
        <div id="collapseThree" class="panel-collapse collapse">
            <div class="panel-body">
                Anim pariatur cliche reprehenderit, 
                enim eiusmod high life accusamus terry richardson ad squid.
            </div>
        </div>
    </div>
</div>
    
    </div>


<div id="investindebt">
    <h4>Companies - Raise capital in return of equity</h4>
<div class="panel-group" id="accordion5">
    <!-- First Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse" 
                 data-target="#collapseOne">
                 Collapsible Group Item #1
             </h4>
        </div>
        <div id="collapseOne" class="panel-collapse collapse">
            <div class="panel-body">
                Anim pariatur cliche reprehenderit, 
                enim eiusmod high life accusamus terry richardson ad squid.
            </div>
        </div>
    </div>
    
    <!-- Second Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title" 
                 data-toggle="collapse" 
                 data-target="#collapseTwo">
                 Collapsible Group Item #2
             </h4>
        </div>
        <div id="collapseTwo" class="panel-collapse collapse">
            <div class="panel-body">
                Anim pariatur cliche reprehenderit, 
                enim eiusmod high life accusamus terry richardson ad squid.
            </div>
        </div>
    </div>
    
    <!-- Third Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse"
                 data-target="#collapseThree">
                 Collapsible Group Item #3
             </h4>
        </div>
        <div id="collapseThree" class="panel-collapse collapse">
            <div class="panel-body">
                Anim pariatur cliche reprehenderit, 
                enim eiusmod high life accusamus terry richardson ad squid.
            </div>
        </div>
    </div>
</div>
    
    </div>


<div id="raisecapitalequity">
    <h4>Companies - Raise capital as debt</h4>
<div class="panel-group" id="accordion6">
    <!-- First Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse" 
                 data-target="#collapseOne">
                 Collapsible Group Item #1
             </h4>
        </div>
        <div id="collapseOne" class="panel-collapse collapse">
            <div class="panel-body">
                Anim pariatur cliche reprehenderit, 
                enim eiusmod high life accusamus terry richardson ad squid.
            </div>
        </div>
    </div>
    
    <!-- Second Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title" 
                 data-toggle="collapse" 
                 data-target="#collapseTwo">
                 Collapsible Group Item #2
             </h4>
        </div>
        <div id="collapseTwo" class="panel-collapse collapse">
            <div class="panel-body">
                Anim pariatur cliche reprehenderit, 
                enim eiusmod high life accusamus terry richardson ad squid.
            </div>
        </div>
    </div>
    
    <!-- Third Panel -->
    <div class="panel panel-default">
        <div class="panel-heading">
             <h4 class="panel-title"
                 data-toggle="collapse"
                 data-target="#collapseThree">
                 Collapsible Group Item #3
             </h4>
        </div>
        <div id="collapseThree" class="panel-collapse collapse">
            <div class="panel-body">
                Anim pariatur cliche reprehenderit, 
                enim eiusmod high life accusamus terry richardson ad squid.
            </div>
        </div>
    </div>
</div>
    
    </div>



    
    

    <div>
      <script type="text/javascript">
      $(function () {

    var active = true;

    $('#collapse-init').click(function () {
        if (active) {
            active = false;
            $('.panel-collapse').collapse('show');
            $('.panel-title').attr('data-toggle', '');
            $(this).text('Enable accordion behavior');
        } else {
            active = true;
            $('.panel-collapse').collapse('hide');
            $('.panel-title').attr('data-toggle', 'collapse');
            $(this).text('Disable accordion behavior');
        }
    });
    
    $('#accordion1').on('show.bs.collapse', function () {
        if (active) $('#accordion1 .in').collapse('hide');
    });
     $('#accordion2').on('show.bs.collapse', function () {
        if (active) $('#accordion2 .in').collapse('hide');
    });
      $('#accordion3').on('show.bs.collapse', function () {
        if (active) $('#accordion3 .in').collapse('hide');
    });
       $('#accordion4').on('show.bs.collapse', function () {
        if (active) $('#accordion4 .in').collapse('hide');
    });
        $('#accordion5').on('show.bs.collapse', function () {
        if (active) $('#accordion5 .in').collapse('hide');
    });
         $('#accordion6').on('show.bs.collapse', function () {
        if (active) $('#accordion6 .in').collapse('hide');
    });

});


      </script>
</div>
</div>
</section>

<?php require('footer.php'); ?>