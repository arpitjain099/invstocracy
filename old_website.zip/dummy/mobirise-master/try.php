
  
  

  

  <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.js"></script>

  

  

  

  
    <link rel="stylesheet" type="text/css" href="http://jsfiddle.net/css/result-light.css">
  

  

  <style type="text/css">
    body { font-family:'Arial'; color:#646464; }		
	.continents-wrap { float:left; width:20%; margin:0 5% 0 0; padding:0; }		
	.flowers-wrap { float:left; width:20%; margin:0 5% 0 0; padding:0; position:relative; }	
	.flowers { float:left; width:50%; }
	.flowers div { float:left; width:90%; height:68px; line-height:68px; padding:0 5%; background:#eee; margin:0 0 1px; position:relative; }	
  </style>

  <title></title>

  
    


  
</head>
<body>