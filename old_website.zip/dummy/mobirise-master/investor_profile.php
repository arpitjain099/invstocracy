
<?php require('header.php'); ?>

  <script src="assets/bootstrap/js/bootstrap.min.js"></script>

  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
 
<section class="mbr-box mbr-section mbr-section--relative mbr-section--fixed-size  mbr-section--bg-adapted mbr-parallax-background mbr-after-navbar" id="header1-73" >
    <div class="mbr-box__magnet mbr-box__magnet--sm-padding mbr-box__magnet--center-left">
        <div class="mbr-overlay" style="opacity: 0.6; background-color: rgb(76, 105, 114);"></div>
        <div class="mbr-box__container mbr-section__container container">
            <div class="mbr-box mbr-box--stretched"><div class="mbr-box__magnet mbr-box__magnet--center-left">
                 <div class="col-xs-18 col-sm-12 col-md-12">
         
            <center><img src="assets/images/investor_profile.png"></center>
              <div class="caption">
                <h4><center>ABC</center></h4>
                <p><center>Entrepreneur, Growth Hacker, Blogger</center></p>
                <p><center>New Delhi, IN</center></p>
            </div>
          <div class="mbr-buttons  mbr-buttons--left"><center><a class="mbr-buttons__btn btn btn-lg animated fadeInUp delay btn-warning" data-toggle="modal" href="#knowmore">Know more!</a></center>
        </div>
            </div></div>
        </div>
      
    </div>
</section>



<section class="mbr-box mbr-section mbr-section--relative mbr-section--fixed-size mbr-section--full-height mbr-section--bg-adapted mbr-parallax-background mbr-after-navbar" id="header1-73" >
    <div class=" mbr-box__magnet--sm-padding mbr-box__magnet--center-left">


<div class="container">
  <ul class="nav nav-pills nav-justified">
    <li class="active"><a data-toggle="pill" href="#profile">Profile</a></li>
    <li><a data-toggle="pill" href="#portfolio">Portfolio</a></li>
    <li><a data-toggle="pill" href="#following">Following</a></li>
  </ul>
  
  <div class="tab-content">
    <div id="profile" class="tab-pane fade in active"><br>
Investor type :  Angel<br>
Linkedin :    Not Available<br>
Twitter :   Not Available<br><br>

<h3>Current affiliation</h3>
Current Organization :  Wipro<br>
Designation : Not Available
City :  Bangalore<br>
State :    Karnataka<br>
Country :    India<br><br>

<h3>Interests</h3>
Small business<br>
Advertising<br>
Marketing

<h3>Investment Preferences</h3>
No. of investments per year: 5<br>
Typical Investment Amount INR: 2-5 lacs
</p>
    </div>
    <div id="portfolio" class="tab-pane fade">
      <br>
      Not available.
    </div>
    <div id="following" class="tab-pane fade">
      <br>
         <div class="col-xs-18 col-sm-6 col-md-3">
          <div class="thumbnail flower"  data-category="green large medium africa">
            <img src="http://placehold.it/500x250/EEE">
              <div class="caption">
                <h4>Company name</h4>
                <p>Brief description of what you do. Brief description of what you do. Brief description of what you do. Brief description of what you do. Brief description of what you do. </p>
                <a href="#" class="btn btn-default btn-xs pull-right" role="button"></a> <a href="#" class="btn btn-info btn-xs" role="button">View offering</a> 
            </div>
          </div>
        </div>
        <div class="col-xs-18 col-sm-6 col-md-3">
          <div class="thumbnail flower" data-category="green yellow large antarctica">
            <img src="http://placehold.it/500x250/EEE">
              <div class="caption">
                <h4>Company name</h4>
                <p>Brief description of what you do. Brief description of what you do. Brief description of what you do. Brief description of what you do. Brief description of what you do. </p>
                <a href="#" class="btn btn-default btn-xs pull-right" role="button"></a> <a href="#" class="btn btn-info btn-xs" role="button">View offering</a>
            </div>
          </div>
        </div>

        <div class="col-xs-18 col-sm-6 col-md-3">
          <div class="thumbnail flower" data-category="blue tiny south-america">
            <img src="http://placehold.it/500x250/EEE">
              <div class="caption">
                <h4>Company name</h4>
                <p>Brief description of what you do. Brief description of what you do. Brief description of what you do. Brief description of what you do. Brief description of what you do. </p>
                <a href="#" class="btn btn-default btn-xs pull-right" role="button"></a> <a href="#" class="btn btn-info btn-xs" role="button">View offering</a> 
            </div>
          </div>
        </div>

         <div class="col-xs-18 col-sm-6 col-md-3">
          <div class="thumbnail flower" data-category="blue tiny south-america">
            <img src="http://placehold.it/500x250/EEE">
              <div class="caption">
                <h4>Company name</h4>
                <p>Brief description of what you do. Brief description of what you do. Brief description of what you do. Brief description of what you do. Brief description of what you do. </p>
                <a href="#" class="btn btn-default btn-xs pull-right" role="button"></a> <a href="#" class="btn btn-info btn-xs" role="button">View offering</a> 
            </div>
          </div>
        </div>

    </div>
        
  </div>
</div>


</div>
</section>

<?php require('footer.php'); ?>