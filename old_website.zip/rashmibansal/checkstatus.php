<?php 
header('Access-Control-Allow-Origin: *');
$con=mysqli_connect("localhost","rbansal","rbansal","rashmibansal");
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
    echo "<br />";
  }
 // $email=$_POST['email'];
//$data=$_POST['data'];

$email="arpitjain099@gmail.com";
$data="shsf1";

$result = mysqli_query($con,"SELECT * FROM `users` WHERE email = '$email'");

   if($result->num_rows > 0)
   {
        while($row = $result->fetch_assoc()) 
        {
        $response_text= $row["books"];
        $response= $row["books"];
        $response= json_decode($response);
        $count=count($response);
        if (in_array($data,$response))
        {
          
        echo "ok";
        return;
      }
        else if (!in_array ($data,$response) && $count<2)
          {
            $response[] = $data;
          $response=json_encode($response);
          $sql = "UPDATE content SET content=$respone WHERE email='$email'";

          if ($conn->query($sql) === TRUE) {
              echo "Record updated successfully";
          } 
          else {
              echo "Error updating record: " . $conn->error;
          }
            echo "ok1";
            return;
          }
        else {
          echo "buy";
          return;
        }
    }
     
   }
  else
    {
    echo "bad request";return;
    }

}
?>