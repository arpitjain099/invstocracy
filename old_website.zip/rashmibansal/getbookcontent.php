<?php 
header('Access-Control-Allow-Origin: *');
$con=mysqli_connect("localhost","rbansal","rbansal","rashmibansal");
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
    echo "<br />";
  }
$data=$_POST['data'];

$result = mysqli_query($con,"SELECT * FROM `content` WHERE data= '$data'");

   if($result->num_rows > 0){
while($row = $result->fetch_assoc()) {
echo $row["content"];
    }
     
   }
else{
echo "bad request";return;

}
 
?>