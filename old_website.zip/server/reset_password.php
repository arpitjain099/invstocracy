<?php 
header('Access-Control-Allow-Origin: *');

$con=mysqli_connect("localhost","rbansal","rbansal","rashmibansal");
if (mysqli_connect_errno($con))
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
    echo "<br />";
  }


  $email=$_POST["email"];
$newpassword=md5(time().$email);

$sql = "UPDATE `users_fmv` SET password='$newpassword' WHERE email='$email'";
$result = mysqli_query($con,$sql);
  if ($result)
     { echo "OK";return;}
   
?>