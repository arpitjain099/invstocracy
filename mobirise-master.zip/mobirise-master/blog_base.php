<?php require('header.php'); ?>


<section class="content-2 simple col-1 col-undefined mbr-parallax-background mbr-after-navbar" id="content5-77" >
    <div class="mbr-overlay" style="opacity: 0.6; background-color: rgb(0, 0, 0);"></div>
    <div class="container">
        <div class="row">
            <div>
                <div class="thumbnail">
                    <div class="caption">
                        <h3>BOOTSTRAP BLOG TEMPLATE</h3>
                        <div><p>Make your own bootstrap blog in minutes! <br></p></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="mbr-section" id="header3-78">
    <div class="mbr-section__container container mbr-section__container--first">
        <div class="mbr-header mbr-header--wysiwyg row">
            <div class="col-sm-8 col-sm-offset-2">
                <h3 class="mbr-header__text">DROP-DEAD EASY BOOTSTRAP BLOG&nbsp;</h3>
                <p class="mbr-header__subtext">By John Smith posted July 30, 2016</p>
            </div>
        </div>
    </div>
</section>

<section class="mbr-section" id="content1-79">
    <div class="mbr-section__container container mbr-section__container--middle">
        <div class="row">
            <div class="mbr-article mbr-article--wysiwyg col-sm-8 col-sm-offset-2"><p>Proin id eros arcu. Integer neque urna, malesuada vel iaculis ac, elementum ut mauris. Proin auctor sapien eu lacus congue, tincidunt luctus nisi egestas. Pellentesque venenatis risus id odio ullamcorper commodo. Mauris pellentesque sapien commodo elit condimentum porta a at purus. Nam vitae odio et augue semper ultrices. Vestibulum ut neque vel elit commodo euismod. Morbi viverra sapien eu sapien ultricies egestas. Mauris porta massa vitae euismod iaculis. Sed finibus enim eu eleifend suscipit. Suspendisse molestie rutrum interdum.&nbsp;</p><blockquote><em>Nullam at tellus a ante dictum sagittis. Aenean malesuada, turpis non aliquam blandit, nisl dui pellentesque tortor, malesuada consectetur sem lectus sed lacus. Nulla nec turpis mattis dui ornare blandit. Ut leo nisl, tempus ut bibendum in, iaculis quis felis. Aliquam et lorem vel dolor tincidunt vulputate vel sed lacus. Morbi tristique elementum vehicula. Duis sem tellus, porta in leo sed, porttitor aliquet magna. Ut cursus erat sed pulvinar semper. Donec gravida porttitor arcu, sed vulputate libero. Morbi non justo ac tellus tempus ornare. Nam tortor augue, commodo eget lobortis non, consectetur eget </em>eros<em>. In hac habitasse platea dictumst. Nam congue odio neque, in tempus sapien faucibus non.&nbsp;</em></blockquote></div>
        </div>
    </div>
</section>

<footer class="mbr-section mbr-section--relative mbr-section--fixed-size" id="footer1-76" style="background-color: rgb(68, 68, 68);">
    
    <div class="mbr-section__container container">
        <div class="mbr-footer mbr-footer--wysiwyg row">
            <div class="col-sm-12">
                <p class="mbr-footer__copyright"></p><p>Copyright (c) 2015 Company Name. <a href="https://mobirise.com/bootstrap-template/license.txt" class="text-gray">License</a></p><p></p>
            </div>
        </div>
    </div>
</footer>


  <script src="assets/jquery/jquery.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smooth-scroll/SmoothScroll.js"></script>
  <script src="assets/jarallax/jarallax.js"></script>
  <script src="assets/bootstrap-carousel-swipe/bootstrap-carousel-swipe.js"></script>
  <script src="assets/masonry/masonry.pkgd.min.js"></script>
  <script src="assets/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/mobirise/js/script.js"></script>
  <script src="assets/mobirise-gallery/script.js"></script>
  
  
</body>
</html>